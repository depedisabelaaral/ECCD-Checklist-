
import React, { useState, useMemo } from 'react';
import { Learner, User } from '../types';
import { Search, Plus, FileSpreadsheet, CheckCircle2, ClipboardList, Trash2, Pencil, Calendar, Info, Bell, X, Users as UsersIcon, CalendarDays } from 'lucide-react';
import * as XLSX from 'xlsx';

interface LearnerListProps {
  user: User;
  learners: Learner[];
  startDateFilter: string;
  setStartDateFilter: (date: string) => void;
  onAddLearner: () => void;
  onViewAssessments: (learner: Learner) => void;
  onImportLearners: (newLearners: Learner[]) => void;
  onDeleteLearner: (id: string) => void;
  onEditLearner: (learner: Learner) => void;
}

const LearnerList: React.FC<LearnerListProps> = ({ 
  user,
  learners, 
  startDateFilter,
  setStartDateFilter,
  onAddLearner, 
  onViewAssessments, 
  onImportLearners, 
  onDeleteLearner, 
  onEditLearner 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [previewData, setPreviewData] = useState<Learner[] | null>(null);

  const filtered = useMemo(() => learners.filter(l => {
    const matchesSearch = l.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         l.lrn.includes(searchTerm);
    const matchesDate = startDateFilter === '' || l.dateOfBeginningOfClasses === startDateFilter;
    return matchesSearch && matchesDate;
  }), [learners, searchTerm, startDateFilter]);

  // SPECIFIC TASK: Categorize by Gender and Sort by Section primarily
  const categorized = useMemo(() => {
    const sorted = [...filtered].sort((a, b) => {
      // Primary sort by Section
      const sectionA = a.section || '';
      const sectionB = b.section || '';
      const sectionCompare = sectionA.localeCompare(sectionB);
      if (sectionCompare !== 0) return sectionCompare;
      
      // Secondary sort by Name
      return a.name.localeCompare(b.name);
    });

    return {
      Male: sorted.filter(l => l.gender === 'Male'),
      Female: sorted.filter(l => l.gender === 'Female')
    };
  }, [filtered]);

  const calculateAgeAtBeginningOfSY = (birthday: string, startDate: string | undefined, schoolYear: string) => {
    if (!birthday) return "---";
    
    // Robust date parsing for different formats
    const bParts = birthday.split(/[-/]/);
    if (bParts.length !== 3) return "---";
    
    let bYear: number, bMonth: number, bDay: number;
    const yearIdx = bParts.findIndex(p => p.length === 4);
    
    if (yearIdx === 0) {
      bYear = parseInt(bParts[0]);
      bMonth = parseInt(bParts[1]);
      bDay = parseInt(bParts[2]);
    } else if (yearIdx === 2) {
      bYear = parseInt(bParts[2]);
      const p0 = parseInt(bParts[0]);
      const p1 = parseInt(bParts[1]);
      if (p0 > 12) {
        bDay = p0;
        bMonth = p1;
      } else {
        bMonth = p0;
        bDay = p1;
      }
    } else {
      bYear = parseInt(bParts[0]);
      bMonth = parseInt(bParts[1]);
      bDay = parseInt(bParts[2]);
    }
    
    if (isNaN(bYear) || isNaN(bMonth) || isNaN(bDay)) return "---";

    let targetYear: number;
    let targetMonth: number;
    let targetDay: number;

    if (startDate && startDate !== '') {
      const sParts = startDate.split(/[-/]/);
      const sYearIdx = sParts.findIndex(p => p.length === 4);
      if (sYearIdx === 0) {
        targetYear = parseInt(sParts[0]);
        targetMonth = parseInt(sParts[1]);
        targetDay = parseInt(sParts[2]);
      } else if (sYearIdx === 2) {
        targetYear = parseInt(sParts[2]);
        targetMonth = parseInt(sParts[0]);
        targetDay = parseInt(sParts[1]);
      } else {
        targetYear = parseInt(sParts[0]);
        targetMonth = parseInt(sParts[1]);
        targetDay = parseInt(sParts[2]);
      }
    } else if (schoolYear) {
      const startYearMatch = schoolYear.match(/^(\d{4})/);
      targetYear = startYearMatch ? parseInt(startYearMatch[1]) : new Date().getFullYear();
      targetMonth = 6;
      targetDay = 1;
    } else {
      return "---";
    }

    if (isNaN(targetYear) || isNaN(targetMonth) || isNaN(targetDay)) return "---";

    let y = targetYear - bYear;
    let m = targetMonth - bMonth;

    if (targetDay < bDay) {
      m--;
    }

    if (m < 0) {
      y--;
      m += 12;
    }

    if (y < 0) return "---";
    
    return `${y} Year${y !== 1 ? 's' : ''}, ${m} Month${m !== 1 ? 's' : ''}`;
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = new Uint8Array(event.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array', cellDates: true });
        
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        const rows: any[][] = XLSX.utils.sheet_to_json(worksheet, { 
          header: 1, 
          defval: "",
          blankrows: true 
        });
        
        if (!rows || rows.length < 7) {
          alert("Import Error: The file does not have enough rows. Data should start at Row 7.");
          return;
        }

        // TASK: Get Section from cell AM4 (Row 4, Column 39)
        let detectedSection = '';
        if (rows[3] && rows[3][38]) {
          detectedSection = String(rows[3][38]).trim().toUpperCase();
        }

        let sectionColIdx = -1;
        let ageColIdx = -1;
        let detectedAdviser = '';
        let detectedSchoolHead = '';
        let detectedSchoolName = user.schoolName || '';
        let detectedSchoolId = user.schoolId || '';
        let detectedSchoolYear = '2024-2025';
        
        // Scan header rows for other metadata
        for (let r = 0; r < Math.min(rows.length, 15); r++) {
          const row = rows[r];
          if (!row) continue;
          
          for (let c = 0; c < row.length; c++) {
            const cellVal = String(row[c] || "").toUpperCase();
            
            if (cellVal.includes('SCHOOL NAME')) {
              detectedSchoolName = String(row[c+1] || row[c+2] || "").trim().toUpperCase();
            }
            if (cellVal.includes('SCHOOL ID')) {
              detectedSchoolId = String(row[c+1] || row[c+2] || "").trim().toUpperCase();
            }
            if (cellVal.includes('SCHOOL YEAR') || cellVal.includes('S.Y.')) {
              const combinedText = cellVal + " " + String(row[c+1] || "").toUpperCase();
              const match = combinedText.match(/(\d{4}\s*-\s*\d{4})/);
              if (match) detectedSchoolYear = match[0].replace(/\s/g, '');
            }
            
            if (cellVal === 'SECTION') {
              sectionColIdx = c;
            }
            
            if (cellVal.includes('AGE AS OF 1ST FRIDAY JUNE')) {
              ageColIdx = c;
            }

            // Fallback Section detection if AM4 was empty
            if (!detectedSection && cellVal.includes('SECTION')) {
              const match = String(row[c]).match(/SECTION[:\s-]+([^\s][^:]*)/i);
              if (match && match[1]) {
                detectedSection = match[1].trim().toUpperCase();
              } else {
                const nextVal = String(row[c+1] || "").trim();
                if (nextVal) {
                    detectedSection = nextVal.toUpperCase();
                }
              }
            }

            if (cellVal.includes("PREPARED BY")) {
               for (let k = 1; k <= 5; k++) {
                 const valBelow = rows[r+k]?.[c];
                 if (valBelow && String(valBelow).trim() !== "") {
                   detectedAdviser = String(valBelow).trim();
                   break;
                 }
               }
            }

            if (cellVal.includes("CERTIFIED CORRECT:")) {
               detectedSchoolHead = String(rows[r+1]?.[c] || rows[r+2]?.[c] || "").trim().toUpperCase();
            }
          }
        }

        const validLearners: Learner[] = [];
        const startRowIndex = 6; 
        const endRowIndex = Math.min(rows.length - 1, 500);

        for (let i = startRowIndex; i < endRowIndex; i++) {
          const row = rows[i];
          if (!row || row.length === 0) continue;

          const firstCol = String(row[0] || "").toUpperCase();
          const secondCol = String(row[2] || "").toUpperCase();
          if (
            firstCol.includes("TOTAL") || 
            secondCol.includes("TOTAL") || 
            secondCol.includes("COMBINED") ||
            (firstCol === "" && secondCol === "")
          ) {
            continue; 
          }

          const colAValue = row[0];
          let lrnString = "";

          if (typeof colAValue === 'number') {
            lrnString = colAValue.toLocaleString('fullwide', { useGrouping: false });
          } else {
            lrnString = String(colAValue || "").trim();
            if (lrnString.toLowerCase().includes('e')) {
              const num = Number(lrnString);
              if (!isNaN(num)) {
                lrnString = num.toLocaleString('fullwide', { useGrouping: false });
              }
            }
          }

          const cleanLRN = lrnString.replace(/\D/g, "");

          if (cleanLRN.length > 0) {
            const nameRaw = String(row[2] || "").trim();
            const sexRaw = String(row[3] || "").trim().toUpperCase();
            const colGRaw = row[6] !== undefined ? String(row[6]).trim().toUpperCase() : "---";
            
            let detectedGender: 'Male' | 'Female' = 'Male';
            if (colGRaw === 'F' || colGRaw === 'FEMALE' || colGRaw.startsWith('F')) {
              detectedGender = 'Female';
            } else if (sexRaw === 'F' || sexRaw === 'FEMALE' || sexRaw.startsWith('F')) {
              detectedGender = 'Female';
            }

            let bday = '';
            if (row[7] instanceof Date) {
              bday = row[7].toISOString().split('T')[0];
            } else if (row[7]) {
              const dateVal = row[7];
              if (typeof dateVal === 'number') {
                const date = new Date((dateVal - 25569) * 86400 * 1000);
                bday = date.toISOString().split('T')[0];
              } else {
                bday = String(dateVal).trim();
              }
            }

            const addr = row.slice(17, 23).map(p => String(p || "").trim()).filter(Boolean).join(', ');
            const rowSection = sectionColIdx !== -1 ? String(row[sectionColIdx] || "").trim() : "";
            const learnerSection = rowSection || detectedSection || '---';
            
            const learnerAge = ageColIdx !== -1 ? (row[ageColIdx] === "" ? 0 : Number(row[ageColIdx])) : (parseInt(String(row[9] || '0')) || 0);

            validLearners.push({
              id: Math.random().toString(36).substr(2, 9),
              lrn: cleanLRN,
              name: nameRaw || 'Unknown Learner',
              gender: detectedGender,
              birthday: bday,
              age: learnerAge,
              address: addr || 'N/A',
              fathersName: String(row[27] || '').trim(),
              mothersName: String(row[31] || '').trim(),
              schoolId: detectedSchoolId || user.schoolId || 'sch-1',
              handedness: 'Right',
              fathersOccupation: '',
              mothersOccupation: '',
              fathersEducation: '',
              mothersEducation: '',
              numSiblings: 0,
              birthOrder: '',
              status: 'ENROLLED',
              excelColG: colGRaw,
              schoolYear: detectedSchoolYear,
              dateOfBeginningOfClasses: startDateFilter, 
              section: learnerSection,
              adviser: detectedAdviser,
              schoolHeadName: detectedSchoolHead
            });
          }
        }

        if (validLearners.length > 0) {
          setPreviewData(validLearners);
        } else {
          alert("Import Failed: No valid records found.");
        }
      } catch (error) {
        console.error("Excel Import Error:", error);
        alert("Error reading file.");
      }
    };
    reader.readAsArrayBuffer(file);
    e.target.value = ''; 
  };

  const confirmImport = () => {
    if (previewData) {
      onImportLearners(previewData);
      setImportStatus(`Successfully imported ${previewData.length} learners into the system.`);
      setPreviewData(null);
      setTimeout(() => setImportStatus(null), 6000);
    }
  };

  const renderTableRows = (learnersList: Learner[], gender: 'Male' | 'Female') => {
    return (
      <React.Fragment key={gender}>
        {learnersList.length > 0 && (
          <tr className="bg-gray-50/80">
            <td colSpan={6} className="px-6 py-1 border border-gray-200">
              <div className="flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${gender === 'Male' ? 'bg-blue-500' : 'bg-pink-500'}`}></span>
                <span className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-500">
                  {gender} Category ({learnersList.length})
                </span>
              </div>
            </td>
          </tr>
        )}
        {learnersList.map((learner) => (
          <tr key={learner.id} className="hover:bg-blue-50/30 transition-colors group">
            <td className="px-6 py-1.5 border border-gray-200">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs shrink-0 shadow-sm ${
                  learner.gender === 'Female' ? 'bg-pink-100 text-pink-700' : 'bg-blue-100 text-blue-700'
                }`}>
                  {learner.name[0]}
                </div>
                <div>
                  <div className="font-bold text-gray-900 text-[13px] leading-tight uppercase">{learner.name}</div>
                  <div className="text-[9px] text-gray-400 font-mono tracking-tight">{learner.lrn}</div>
                </div>
              </div>
            </td>
            <td className="px-6 py-1.5 text-center border border-gray-200">
              <div className="flex flex-col items-center">
                <span className="px-2 py-0.5 bg-slate-50 border border-slate-100 text-slate-600 rounded text-[9px] font-black uppercase tracking-widest">
                  {learner.section || '---'}
                </span>
                {learner.adviser && <span className="text-[8px] text-gray-400 font-bold uppercase mt-0.5">Facilitator: {learner.adviser}</span>}
              </div>
            </td>
            <td className="px-6 py-1.5 text-center border border-gray-200">
               <div className="flex flex-col items-center">
                  <span className="text-[13px] font-bold text-gray-700 flex items-center gap-2">
                     <Calendar className="w-3 h-3 text-blue-400 pointer-events-none" />
                     {learner.birthday || "---"}
                  </span>
               </div>
            </td>
            <td className="px-6 py-1.5 text-center border border-gray-200">
              <span className={`px-2 py-0.5 rounded-md text-[11px] font-black uppercase ${learner.gender === 'Female' ? 'bg-pink-50 text-pink-600' : 'bg-blue-50 text-blue-600'}`}>
                {learner.excelColG || learner.gender}
              </span>
            </td>
            <td className="px-6 py-1.5 text-center text-[13px] font-black text-gray-700 border border-gray-200">{calculateAgeAtBeginningOfSY(learner.birthday, learner.dateOfBeginningOfClasses, learner.schoolYear)}</td>
            <td className="px-6 py-1.5 text-right border border-gray-200">
              <div className="flex items-center justify-end gap-1 group-hover:opacity-100 transition-opacity">
                <button 
                  onClick={() => onViewAssessments(learner)}
                  className="p-1.5 text-blue-600 hover:bg-blue-100 rounded-xl transition-all"
                  title="View Assessments"
                >
                  <ClipboardList className="w-4 h-4 pointer-events-none" />
                </button>
                <button 
                  onClick={() => onEditLearner(learner)}
                  className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"
                  title="Edit Learner Profile"
                >
                  <Pencil className="w-4 h-4 pointer-events-none" />
                </button>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteLearner(learner.id);
                  }}
                  className="p-1.5 text-red-400 hover:text-red-700 hover:bg-red-100 rounded-xl transition-all shadow-sm"
                  title="Delete Learner Profile"
                >
                  <Trash2 className="w-4 h-4 pointer-events-none" />
                </button>
              </div>
            </td>
          </tr>
        ))}
      </React.Fragment>
    );
  };

  return (
    <div className="space-y-6">
      {importStatus && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-6 py-4 rounded-2xl flex items-center justify-between gap-4 animate-in fade-in slide-in-from-top-4 shadow-xl shadow-emerald-500/5">
          <div className="flex items-center gap-3">
             <div className="p-2 bg-emerald-100 rounded-xl">
                <Bell className="w-5 h-5 text-emerald-600 animate-bounce" />
             </div>
             <div>
                <p className="text-xs font-black uppercase tracking-widest text-emerald-600 leading-none mb-1">System Notification</p>
                <p className="font-bold text-sm">{importStatus}</p>
             </div>
          </div>
          <button onClick={() => setImportStatus(null)} className="p-2 hover:bg-emerald-100 rounded-xl transition-colors">
             <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {previewData && (
        <div className="fixed inset-0 z-[60] bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-7xl max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-white sticky top-0 z-10">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-blue-50 rounded-xl"><FileSpreadsheet className="w-6 h-6 text-blue-600 pointer-events-none" /></div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">SF1 Import Preview</h3>
                  <p className="text-sm text-gray-500">Acknowledging {previewData.length} learners for {user.schoolName || 'your school'}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <button onClick={() => setPreviewData(null)} className="px-5 py-2.5 text-sm font-semibold text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">Discard</button>
                <button onClick={confirmImport} className="px-7 py-2.5 text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-lg shadow-blue-200 transition-all flex items-center gap-2">
                   <CheckCircle2 className="w-4 h-4" />
                   Acknowledge & Import
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-auto p-6 bg-gray-50/50">
              <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
                <table className="w-full text-left text-[11px] border-collapse">
                  <thead className="bg-gray-100 border-b border-gray-200 text-gray-600 font-bold uppercase tracking-wider sticky top-0 z-10">
                    <tr>
                      <th className="px-3 py-4 border-r border-gray-200">LRN</th>
                      <th className="px-3 py-4 border-r border-gray-200">Name</th>
                      <th className="px-3 py-4 border-r border-gray-200 text-center bg-blue-50 text-blue-600">Section</th>
                      <th className="px-3 py-4 border-r border-gray-200 text-center">Birthdate</th>
                      <th className="px-3 py-4 border-r border-gray-200 text-center bg-emerald-50 text-emerald-700">Age as of Beginning of SY</th>
                      <th className="px-3 py-4 border-r border-gray-200">Adviser</th>
                      <th className="px-3 py-4 text-center">School ID</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {previewData.map((p, idx) => (
                      <tr key={idx} className="hover:bg-blue-50/30 transition-colors">
                        <td className="px-3 py-4 border-r border-gray-100 font-mono text-blue-600 font-bold">{p.lrn}</td>
                        <td className="px-3 py-4 border-r border-gray-100 font-semibold text-gray-900">{p.name}</td>
                        <td className="px-3 py-4 border-r border-gray-100 text-center font-bold text-blue-600 bg-blue-50/20 uppercase">
                          {p.section}
                        </td>
                        <td className="px-3 py-4 border-r border-gray-200 text-center font-bold text-gray-700">
                          {p.birthday || "---"}
                        </td>
                        <td className="px-3 py-4 border-r border-gray-100 text-center text-emerald-700 font-black">
                          {calculateAgeAtBeginningOfSY(p.birthday, p.dateOfBeginningOfClasses, p.schoolYear)}
                        </td>
                        <td className="px-3 py-4 border-r border-gray-100 truncate max-w-[150px] text-gray-500 uppercase italic font-bold">{p.adviser}</td>
                        <td className="px-3 py-4 text-center font-bold text-blue-600">
                          {p.schoolId}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col lg:flex-row items-center justify-between gap-4">
        <div className="flex flex-col sm:flex-row items-center gap-4 w-full lg:w-auto">
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5 pointer-events-none" />
            <input
              type="text"
              placeholder="Search by name or LRN..."
              className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none shadow-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest whitespace-nowrap">Date of Beginning of Classes:</label>
            <div className="relative w-full sm:w-48">
              <CalendarDays className="absolute left-3 top-1/2 -translate-y-1/2 text-blue-400 w-5 h-5 pointer-events-none" />
              <input
                type="date"
                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none shadow-sm text-sm font-semibold text-gray-700"
                value={startDateFilter}
                onChange={(e) => setStartDateFilter(e.target.value)}
                title="Filter by Date of Beginning of Classes"
              />
              {startDateFilter && (
                <button 
                  onClick={() => setStartDateFilter('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-red-500 transition-colors"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3 w-full lg:w-auto">
          {/* SPECIFIC TASK: Disable Import if Date is Empty */}
          <label 
            title={!startDateFilter ? "Please select a Date of Beginning of Classes first" : ""}
            className={`flex-1 lg:flex-none flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl border border-gray-200 bg-white text-gray-700 font-bold text-sm transition-all group shadow-sm ${!startDateFilter ? 'opacity-50 cursor-not-allowed grayscale' : 'hover:border-emerald-500 hover:text-emerald-600 cursor-pointer'}`}
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600 group-hover:scale-110 transition-transform pointer-events-none" />
            <span>Import SF1</span>
            <input 
              type="file" 
              className="hidden" 
              accept=".xls,.xlsx" 
              onChange={handleFileUpload} 
              disabled={!startDateFilter} 
            />
          </label>
          <button 
            onClick={onAddLearner}
            className="flex-1 lg:flex-none flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 text-white font-bold text-sm hover:bg-blue-700 shadow-lg shadow-blue-100 transition-all active:scale-95"
          >
            <Plus className="w-4 h-4 pointer-events-none" />
            <span>Add Learner</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse border border-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-2 text-[10px] font-black text-gray-600 uppercase tracking-wider border border-gray-200 whitespace-nowrap">ID / Name</th>
                <th className="px-6 py-2 text-[10px] font-black text-gray-600 uppercase tracking-wider text-center border border-gray-200 whitespace-nowrap">Section</th>
                <th className="px-6 py-2 text-[10px] font-black text-gray-600 uppercase tracking-wider text-center border border-gray-200 whitespace-nowrap">Birthdate</th>
                <th className="px-6 py-2 text-[10px] font-black text-gray-600 uppercase tracking-wider text-center border border-gray-200 whitespace-nowrap">Sex</th>
                <th className="px-6 py-2 text-[10px] font-black text-gray-600 uppercase tracking-wider text-center border border-gray-200 whitespace-nowrap">Age as of Beginning of SY</th>
                <th className="px-6 py-2 text-[10px] font-black text-gray-600 uppercase tracking-wider text-right border border-gray-200 whitespace-nowrap">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length > 0 ? (
                <>
                  {renderTableRows(categorized.Male, 'Male')}
                  {renderTableRows(categorized.Female, 'Female')}
                </>
              ) : (
                <tr>
                  <td colSpan={6} className="px-6 py-20 text-center border border-gray-200">
                    <div className="flex flex-col items-center gap-2 text-gray-400">
                      <ClipboardList className="w-12 h-12 opacity-20 pointer-events-none" />
                      <p className="font-medium text-sm">No learners found matching your criteria.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default LearnerList;
